#!/bin/bash

# Copyright (c) 2023 Oracle and/or its affiliates. All rights reserved.
#
# See the bottom of this script for the general flow.
#

AddVMOption()
{
  APP_VM_OPTS[${#APP_VM_OPTS[*]}]="$*"
}

#
# Set CPAT_HOME to be canonical paths
#
function setupCPATHome {
  SOURCE="${BASH_SOURCE[0]}"
  # resolve $SOURCE until the file is no longer a symlink
  while [ -h "$SOURCE" ]; do
    DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
    SOURCE="$(readlink "$SOURCE")"
    # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
  done
  DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
  CPAT_HOME="$DIR"
	# echo CPAT_HOME is "$CPAT_HOME"
}

function checkArgs {
  # Check to see if the --connectstring argument contains ":oci:"
  # If it does we won't allow the app to run w/o ORACLE_HOME being set
  CPAT_CONNECT_STRING=""
  argArrayCopy=( "$@" )
  numArgs=${#argArrayCopy[@]}
  # We don't use "i<=numArgs" because if --connectstring occurs last there's
  # no point trying access argArrayCopy[$i+1]
  for (( i=0; i<numArgs; i++ ));
  do
    opt=${argArrayCopy[$i]};
    case "$opt" in
        "--connectstring" )
           arg=${argArrayCopy[$i+1]};
           CPAT_CONNECT_STRING="$arg";;
        "-c" )
           arg=${argArrayCopy[$i+1]};
           CPAT_CONNECT_STRING="$arg";;
        *) ;;
    esac
  done

  #echo "Connect String is $CPAT_CONNECT_STRING"

  THICK_DRIVER_IN_USE="false"

  case $CPAT_CONNECT_STRING in
    *:oci:*)
      THICK_DRIVER_IN_USE="true"
      ;;
    *:oci8:*)
      THICK_DRIVER_IN_USE="true"
      ;;
  esac

  #echo "THICK_DRIVER_IN_USE is $THICK_DRIVER_IN_USE"
}

function checkORACLE_HOME {
  # If using the thick driver ORACLE_HOME must be set
  if [[ $THICK_DRIVER_IN_USE = "true" && -z "$ORACLE_HOME" ]]; then
      echo "Use of a thick JDBC connection string requires that ORACLE_HOME be set. Exiting."
      exit "$FAILURE_STATUS"
  fi

  # ORACLE_HOME and JAVA_HOME can't both be unset
  if [[ -z "$ORACLE_HOME" && -z "$JAVA_HOME" ]]; then
      echo "JAVA_HOME and/or ORACLE_HOME must be set. Exiting."
      exit "$FAILURE_STATUS"
  fi

  # If ORACLE_HOME is set make sure it really points to a directory
  if [ -n "$ORACLE_HOME" ]; then

    if [ ! -d "$ORACLE_HOME" ]; then
      echo "ORACLE_HOME directory $ORACLE_HOME not found. Exiting."
      exit "$FAILURE_STATUS"
    fi

    # Add $ORACLE_HOME/LIB and/or $ORACLE_HOME to the front of LD_LIBRARY_PATH if
    # they're not already in LD_LIBRARY_PATH
    [[ ":$LD_LIBRARY_PATH:" != *":$ORACLE_HOME:"* ]] && export LD_LIBRARY_PATH="$ORACLE_HOME:${LD_LIBRARY_PATH}"
    [[ ":$LD_LIBRARY_PATH:" != *":$ORACLE_HOME/lib:"* ]] && export LD_LIBRARY_PATH="$ORACLE_HOME/lib:${LD_LIBRARY_PATH}"

    # Do the same with LIBPATH (for AIX)
    [[ ":$LIBPATH:" != *":$ORACLE_HOME:"* ]] && export LIBPATH="$ORACLE_HOME:${LIBPATH}"
    [[ ":$LIBPATH:" != *":$ORACLE_HOME/lib:"* ]] && export LIBPATH="$ORACLE_HOME/lib:${LIBPATH}"
  fi
}

function checkSetJAVA_HOME {

  if [ -z "$JAVA_HOME" ]; then
    export JAVA_HOME=${ORACLE_HOME}/jdk
  fi

  JAVA_JVM="$JAVA_HOME"/bin/java

  if [ ! -f "$JAVA_JVM" ]; then
      echo "$JAVA_JVM not found. Exiting."
      exit "$FAILURE_STATUS"
  fi
}

function checkJavaVersion {
  # JAVA_JVM must already have set by checkSetJAVA_HOME

  # JAVA_VERSION_STRING should be set to something like "w.x.y" (e.g. 1.8.123)
  JAVA_VERSION_STRING=$("$JAVA_JVM" -version 2>&1 | cut -s -d '"' -f2)
  # JAVA_VERSION_ARRAY should have elements such as "w", "x", and "y"; we want "w"
  IFS='.' read -ra JAVA_VERSION_ARRAY <<< "$JAVA_VERSION_STRING"

  # JAVA_VERSION should have the "w" of the string "w.x.y"
  JAVA_VERSION=${JAVA_VERSION_ARRAY[0]}

  if [[ ! $JAVA_VERSION =~ ^-?[0-9]+$ ]] ; then
    echo "Unable to determine Java Version.  Exiting."
    exit "$FAILURE_STATUS"
  fi

  # If JAVA_VERSION is "1" then we have the "old" java numbering scheme and need
  # to grab the second digit (the "x" in "w.x.y")
  if [ "$JAVA_VERSION" -eq 1 ]; then
    JAVA_VERSION=${JAVA_VERSION_ARRAY[1]}
  fi

  if [ "$JAVA_VERSION" -lt "$MIN_SUPPORTED_JAVA_VERSION" ]; then
    echo "The version of Java is $JAVA_VERSION which is lower than the minimum supported version of Java $MIN_SUPPORTED_JAVA_VERSION"
    echo "Please define JAVA_HOME to point to a more recent version of java."
    echo "Note any Java $MIN_SUPPORTED_JAVA_VERSION or later JVM can be used; be that JDM from another ORACLE_HOME or a standalone installation of the JVM."
    echo "As long as the JVM has JDBC connectivity to the instance to be analyzed the JVM can be on the database host or anywhere else in their network."
    echo Exiting.
    exit "$FAILURE_STATUS"
  fi

  # For version 11 and higher add options to suppress the "reflective access" message
  if [ "$JAVA_VERSION" -ge "11" ]; then
    AddVMOption --add-opens
    AddVMOption java.base/java.util=ALL-UNNAMED
  fi

}

function setupCLASS_PATH {

  PREMIGRATION_JAR=$CPAT_HOME/lib/"premigration.jar"

  if test -f "$PREMIGRATION_JAR"; then
      OUR_CLASS_PATH="$PREMIGRATION_JAR"
  else
      echo "$PREMIGRATION_JAR cannot be found. Exiting."
      exit "$FAILURE_STATUS"
  fi

  APACHE_CLI_JAR=$CPAT_HOME/lib/"commons-cli-1.9.0.jar"

  if test -f "$APACHE_CLI_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${APACHE_CLI_JAR}
  else
      echo "$APACHE_CLI_JAR cannot be found. Exiting."
      exit "$FAILURE_STATUS"
  fi

  # Using the thick driver requires using Jars from ORACLE_HOME. Additionally,
  # CPAT no longer ships ojdbc7 so now we have to get those from ORACLE_HOME.
  if [[ $THICK_DRIVER_IN_USE = "true" ]]; then
      # we support ojdbc5 through ojdbc11.  Find the "oldest" ojdbc in ORACLE_HOME/jdbc
      OJDBC_JAR=$(find "${ORACLE_HOME}"/jdbc/lib \( -name "ojdbc[5-9].jar" -o -name "ojdbc1[0-1].jar" \) -print | sort -n | tail -1)
      OJDBC_VERSION=$(basename $OJDBC_JAR | sed 's/[^0-9]*\([0-9]*\).*/\1/' )
      if [ "$OJDBC_VERSION" -eq 11 ]; then
          UCP_JAR="$ORACLE_HOME/ucp/lib/ucp11.jar"
      else
          UCP_JAR="$ORACLE_HOME/ucp/lib/ucp.jar"
      fi
      PKI_JAR=$ORACLE_HOME/jlib/oraclepki.jar
      OSDT_CORE_JAR=$ORACLE_HOME/jlib/osdt_core.jar
      OSDT_CERT_JAR=$ORACLE_HOME/jlib/osdt_cert.jar
      ORAI18N_JAR=$ORACLE_HOME/jlib/orai18n.jar
      ONS_JAR=$ORACLE_HOME/opmn/lib/ons.jar
      SIMPLEFAN_JAR=$ORACLE_HOME/jdbc/lib/simplefan.jar
  else
      THE_OJDBC_VERSION=$OJDBC8_VERSION
      OJDBC_JAR=$CPAT_HOME/lib/ojdbc8-${THE_OJDBC_VERSION}.jar
      UCP_JAR=$CPAT_HOME/lib/ucp-${THE_OJDBC_VERSION}.jar
      PKI_JAR=$CPAT_HOME/lib/oraclepki-${THE_OJDBC_VERSION}.jar
      OSDT_CORE_JAR=$CPAT_HOME/lib/osdt_core-${THE_OJDBC_VERSION}.jar
      OSDT_CERT_JAR=$CPAT_HOME/lib/osdt_cert-${THE_OJDBC_VERSION}.jar
      ORAI18N_JAR=$CPAT_HOME/lib/orai18n-${THE_OJDBC_VERSION}.jar
      ONS_JAR=$CPAT_HOME/lib/ons-${THE_OJDBC_VERSION}.jar
      SIMPLEFAN_JAR=$CPAT_HOME/lib/simplefan-${THE_OJDBC_VERSION}.jar
  fi

  if test -f "$OJDBC_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${OJDBC_JAR}
  else
      echo "$OJDBC_JAR not found. Exiting."
      exit "$FAILURE_STATUS"
  fi

  # Add the ucp.jar file to our classpath
  if test -f "$UCP_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${UCP_JAR}
  else
      echo "$UCP_JAR not found. Exiting."
      exit "$FAILURE_STATUS"
  fi

  # Add the oraclepki, osdt_core, osdt_cert, and orai18n jar files to our classpath if found
  if test -f "$PKI_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${PKI_JAR}
  fi
  if test -f "$OSDT_CORE_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${OSDT_CORE_JAR}
  fi
  if test -f "$OSDT_CERT_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${OSDT_CERT_JAR}
  fi
  if test -f "$ORAI18N_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${ORAI18N_JAR}
  fi

  # Add the ons.jar file to our classpath
  if test -f "$ONS_JAR"; then
      OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${ONS_JAR}
  else
      echo "$ONS_JAR not found. Exiting."
      exit "$FAILURE_STATUS"
  fi

  # Add the simplefan.jar file to our classpath
  if test -f "$SIMPLEFAN_JAR"; then
          OUR_CLASS_PATH=${OUR_CLASS_PATH}":"${SIMPLEFAN_JAR}
  else
      echo "$SIMPLEFAN_JAR not found. Exiting."
      exit "$FAILURE_STATUS"
  fi
}

function validateJDBCVersion {
  if [[ "$JAVA_VERSION" -lt "$OJDBC_VERSION" ]]; then
        echo "The version of Java specified by JAVA_HOME ($JAVA_HOME) is $JAVA_VERSION and this version is too old to use with $OJDBC_JAR"
        echo "Please specify a more recent version of Java"
        echo Exiting.
        exit "$FAILURE_STATUS"
  fi
}

function setDefaults {
  # If we fail before running our Java app then exit with 254 to distinguish
  # this failure mode from the application failing (255).  When the application fails
  # there should be a log and possibly an incomplete report but when this script fails
  # neither of these files will exist.
  FAILURE_STATUS=254

  # Make sure we have at least Java 8
  MIN_SUPPORTED_JAVA_VERSION=8

  # Restrict which binaries we might execute
  PATH="/sbin:/usr/sbin:/bin:/usr/bin"

  OJDBC8_VERSION="19.3.0.0"

  # If we're reasonably sure we have a terminal as stdin/out then get the width
  if [[ -t 0  && -t 1  ]]; then
    TPUT="$(tput longname 2>/dev/null)"
    [[ "$TPUT" ]] && export CPAT_TERMINAL_WIDTH=$(tput cols)
  fi

  AddVMOption -Djava.awt.headless=true
  AddVMOption -Djava.net.useSystemProxies=true
}

function runPremigration {
  #echo "OUR_CLAS_PATH is $OUR_CLASS_PATH"

  "$JAVA_HOME"/bin/java "${APP_VM_OPTS[@]}" -cp "$OUR_CLASS_PATH" com.oracle.premigration.PremigrationApp "$@"
}

# General flow:
#   Find the path from which we're being run
#   Make sure ORACLE_HOME is set if we need to (JAVA_HOME not set or thick driver being used)
#   Set JAVA_HOME if needed
#   Make sure the Java version is at least Java 8 (1.8.x)
#   Setup the class path
#   Find the "oldest" ojdbcX.jar file and add that to the classpath or use the one in our lib
#   Add ucp.jar (connection pool) and other OJDBC jars to the classpath
#
# We should end up with something that looks like this:
#   java -cp premigration.jar:$ORACLE_HOME/jdbc/lib/ojdbc6.jar:$ORACLE_HOME/ucp/lib/ucp.jar com.oracle.premigration.PremigrationApp <all arguments passed to us>

setDefaults
checkArgs "$@"
setupCPATHome
checkORACLE_HOME
checkSetJAVA_HOME
checkJavaVersion
setupCLASS_PATH
validateJDBCVersion

runPremigration "$@"
