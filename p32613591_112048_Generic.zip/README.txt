Cloud Premigration Advisor Tool (CPAT) README.txt

Version 25.6.0
Built on 2025/06/17 00:45:28

The Cloud Premigration Advisor Tool is a Java application that can perform
analysis of both the source and the target database instance and provide
information about the suitability of migrating the source database to an
Oracle Cloud offering.

The minimum JRE version required for CPAT is Java 8.

For basic usage information set JAVA_HOME appropriately and execute
premigration.sh (or premigration.cmd on Windows) with the "--help" switch.

For 3rd party license information see the "THIRD_PARTY_LICENSE.txt" in this kit.

For additional information see:
  https://support.oracle.com/epmos/faces/DocumentDisplay?id=2758371.1

Recently Added Features and Enhancements:
  OPTD-612, OPTD-659, OPTD-746: A new command line switch has been introduced:

            --gatherdetails <space-separated-category-values>

            This switch takes one or more "category" values which instruct CPAT
            to gather additional details from the source instance for inclusion
            in CPAT reports.  The default value for --gatherdetails is NONE.

            To have CPAT gather additional information about the data in the
            schemas being migrated use --gatherdetails SCHEMA_OBJECTS

            Use CPAT's "--help" option for more information on command line
            options.

            When CPAT is instructed to gather details on SCHEMA_OBJECTS there
            will be an additional sub-object in the JSON report, "srcSchemaSummary",
            and an additional section in the HTML report titled:
            "Source Database Schema Summary Information". Similarly, other options
            to gather details will also add new fields to the JSON report and new
            sections to the HTML report. You can use ALL to instruct CPAT to
            gather all possible details. By default, no details are gathered.
            For a list of all the information which can extracted by CPAT, please
            refer to Document 2758371.1 in the My Oracle Support portal.

  OPTD-721: CPAT now includes support for two new execution modes: Command Line
            Interface (CLI) mode and Load Password mode. A new enhancement
            introduces the ability to run CPAT interactively via CLI and to
            securely store credentials for automated, unattended executions.
            CLI Mode allows users to execute CPAT from the command line for
            interactive use. When combined with the --noconsole flag, CPAT
            operates in multi-analysis mode, executing multiple analyses
            sequentially without user prompts.
            Load Password Mode enables users to store encrypted database
            credentials in a local keystore. This allows CPAT to run analyses
            without requiring the user to enter passwords at runtime.
            To execute multiple analyses in batch using a configuration
            file and stored passwords, use the following command:

            Examples:

            #Cli mode:
            /premigration.sh --parfile <config-file-path>
            #No console mode:
            /premigration.sh --noconsole --parfile <config-file-path>
            #Load password mode:
            /premigration.sh --parfile <config-file-path> --loadpassword

            Example Configuration File (multi-database):

            # Database 1
            a.targetcloud=ATPD
            a.reportformat=json,text,html
            a.outfileprefix=DB1
            a.username=SYSTEM
            a.connectstring=<connectstring>
            a.migrationmethod=GOLDENGATE,DATAPUMP
            a.full=true
            a.pdbname=ORCLPDB1

            # Database 2
            b.targetcloud=ATPD
            b.reportformat=json,text,html
            b.outfileprefix=DB2
            b.username=SYSTEM
            b.connectstring=<connectstring>
            b.migrationmethod=GOLDENGATE,DATAPUMP
            b.full=true
            b.pdbname=ORCLPDB1

            # Database 3
            c.targetcloud=ATPD
            c.reportformat=json,text,html
            c.outfileprefix=DB3
            c.username=SYSTEM
            c.connectstring=<connectstring>
            c.migrationmethod=GOLDENGATE,DATAPUMP
            c.full=true
            c.pdbname=ORCLPDB1

            Managing Credentials with Load Password Mode (example):
            Starting CPAT Password Loader - Type help for available options
            Creating new CPAT keystore - Password required
            Enter password:
            Enter password again:
            CPAT keystore was successfully created

            >> add orcdb2 -user system
            Enter your secret/Password:
            Re-enter your secret/Password:
            Done
            Database Name Space: orcdb2              User: system

            >> list
            Database Name Space: orcdb2              User: system

            >> add orcdb2 -user SYSTEM -nocheck
            Replacing existing entry system.
            Enter your secret/Password:
            Re-enter your secret/Password:
            Done
            Database Name Space: orcdb2              User: system

            >> exit
            Save the CPAT keystore before exiting [YES|NO]? yes
            Convert the CPAT keystore to auto-login [YES|NO]? yes

            These features enhance automation, security, and flexibility when
            executing CPAT across multiple environments. For a complete list of
            supported options and usage patterns, refer to CPAT’s --help output
            or consult the official documentation.

  OPTD-774: The query for the has_role_privileges check is now recursive. It will
            not just look for roles directly assigned to the user, but also roles
            that are indirectly assigned (role that is granted to a role that is
            granted to a role... that is granted to the user)
            
  OPTD-676: Adding a new check, has_owner_mismatch_index_table, to identify the
            index does not belong to different user than the table it's indexing.

  OPTD-674: Adding a new check, has_users_lack_create_privileges, for users/schemas
            who own objects but lack the privileges to create those objects
    
Recently Fixed Bugs or Other Changes:
  OPTD-613: CPAT HTML and JSON reports now include information on Hybrid
            Columnar Compression tables, High Water Mark statistics, and
            certain Login Triggers

  OPTD-708: Reinforced query for the gg_has_low_streams_pool_size check to also
            look into SHARED_POOL_SIZE or SGA_TARGET/MEMORY_TARGET if
            STREAMS_POOL_SIZE is not set as described by MOS Doc ID 2998659.1

  OPTD-727: CPAT's has_user_defined_pvfs check now assumes that when migrating
            to ADB all user defined password verification functions will be
            created in the ADMIN schema.

  OPTD-792: The following checks have been made obsolete:
              - has_compression_disabled_for_objects
              - has_tables_with_long_raw_datatype


Java 8 is now the minimum required version for CPAT:
  o Customers do not have to install anything on their database host to use CPAT.
  o Customers can use any Java 8 or later JVM be it from another ORACLE_HOME or
    a standalone installation of the JVM.
  o As long as the JVM has JDBC connectivity to the instance they wish to analyze
    that JVM can be on the database host or anywhere else in their network.
  o Customers are welcome to use a JRE from OpenJDK (https://openjdk.org/) should
    they desire.
